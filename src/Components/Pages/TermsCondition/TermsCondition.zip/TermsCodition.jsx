import TcContent from "./TcContent/TcContent";
import TcHeader from "./TcHeader/TcHeader";

const TermsCodition = () => {
    return (
        <div className="xl:px-0 px-4">
           <TcHeader></TcHeader>
           <TcContent></TcContent>
        </div>
    );
};

export default TermsCodition;